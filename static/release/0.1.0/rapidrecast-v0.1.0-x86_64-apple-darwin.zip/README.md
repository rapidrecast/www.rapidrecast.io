# RapidRecast
RapidRecast, anything to anything proxy

# How to do a release

1. Trigger the `Release` workflow manually
2. On github, create a release from the tag.

