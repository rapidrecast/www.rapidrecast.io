# RapidRecast
RapidRecast, anything to anything proxy and API Gateway.

# Features

## Inbound and Outbound connectivity

Sometimes, you are making something that operates as a client and you would like it to have server-like functionality where you handle requests.
This is true for browsers, mobile apps, and anything that tends to be "on-demand" operation.

Other times, you will have a server that holds information, but requires a connection to be made to it to operate.
This means you can handle requests in parallel and take advantage of serverless cost and operation model.

## Push and Pull messaging

Push messaging means that you have a message and you are deciding to send it somewhere.

Pulling (or rather, Polling) is when you connect to something and only expect the messages to be there when you poll.

## Protocols

### HTTP/1.1, HTTP/2, HTTP/3

#### Web Requests

#### Long-polling

#### WebSockets

#### Streamed Requests

### gRPC

Many services written today involve gRPC for it's performance and support of compiled contracts.
RapidRecast can handle gRPC contracts dynamically, even changing while still serving requests or conditionally applying a contract based on given properties (like authentication, port, or any property within the message context)

### Kafka

RapidRecast can take the roll of both a client and a server.
This is useful if you already have Kafka infrastructure you want to leverage to benefit from RapidRecast.

